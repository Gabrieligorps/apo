<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Barangay Basketball Court Permit Application</title>
    <link rel="stylesheet" type="text/css" href="brgypermit.css">
    <link rel="stylesheet" href="reset.css">
    <style>
        body {
            position: relative;
        }

        #term_agreement {
            opacity: 0;
            position: absolute;
            margin-left: 20px; /* Adjust the margin based on your layout */
        }

        label[for="term_agreement"] {
            position: relative;
            cursor: pointer;
            display: inline-block; /* Ensures the label and checkbox are on the same line */
        }

        #term_agreement+label:before {
            content: "";
            position: absolute;
            left: -20px;
            top: 1px;
            width: 15px;
            height: 15px;
            background-color: #fff;
            border: 2px solid #000;
        }

        #term_agreement:checked+label:before {
            content: "✔";
            background-color: white;
            color: black;
            border-color: black;
            font-size: 14px;
            font-weight: bolder;
            text-align: center;
            line-height: 11px;
        }

        #term_agreement_error {
            display: none;
            color: red;
            font-weight: bold;
            margin-top: 5px;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            background-color: rgb(0, 0, 0);
            background-color: rgba(0, 0, 0, 0.4);
        }

        .modal-content {
            background-color: #fefefe;
            margin: 10% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 50%;
            text-align: left;
            border: solid black;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -75%);
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        h2 {
            font-weight: bold;
        }

        .contact-link {
            color: #007bff; /* Change the color as needed */
            text-decoration: underline; /* Add an underline to the link */
            cursor: pointer;
        }

    </style>
</head>
<body class=tentchairs>
    <nav>
        <ul>
            <div class="logo3">
                <img src="images/pemboLogo.png" alt="Barangay Pembo Logo">
            </div>
            <li><a href="mainhtml.php">HOME</a></li>
            <li><a href="Serviceshtml.php">BARANGAY SERVICES</a></li>
            <div class="logo4">
                <img src="images/makatiLogo.png" alt="Barangay Pembo Logo">
            </div>
        </ul>
    </nav>
    
    <form action="tentchairs.php" method="post" onsubmit="return confirmSubmit()">
        <h1>Request for Tent and Chairs</h1>
        <br>
        <div class="success-message">

            <?php
            if (isset($_SESSION['success_message'])) {
                echo $_SESSION['success_message'];
                unset($_SESSION['success_message']); 
            }
            ?>

        </div>
        <div class="error-message">
            
            <?php
            if (isset($_SESSION['error_message'])) {
                echo $_SESSION['error_message'];
                unset($_SESSION['error_message']); 
            }
            ?>
            
        </div><br>

        <div class="container">
            <div class="container1">
                <br><br><br>
                <label for="name">Full Name</label>
                <input type="text" id="name" name="name" value="<?php echo isset($_SESSION['form_values']['name']) ? $_SESSION['form_values']['name'] : ''; ?>" required><br><br>

                <label for="address">Address</label>
                <input type="text" id="address" name="address" value="<?php echo isset($_SESSION['form_values']['address']) ? $_SESSION['form_values']['address'] : ''; ?>" required><br><br>

                <label for="contact">Contact Number</label>
                <input type="tel" id="contact" oninput="validateContact()" name="contact" value="<?php echo isset($_SESSION['form_values']['contact']) ? $_SESSION['form_values']['contact'] : ''; ?>" required>
                <span id="contactIndicator" class="contact-indicator"></span><br><br>

                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" value="<?php echo isset($_SESSION['form_values']['email']) ? $_SESSION['form_values']['email'] : ''; ?>" required><br><br>
            </div>

            <div class="container2">
                <label for="date">Date Requested</label>
                <input type="date" id="date" name="date" value="<?php echo isset($_SESSION['form_values']['date']) ? $_SESSION['form_values']['date'] : ''; ?>" required><br><br>

                <label for="enddate">Requested Until</label>
                <input type="date" id="enddate" name="enddate" value="<?php echo isset($_SESSION['form_values']['enddate']) ? $_SESSION['form_values']['enddate'] : ''; ?>" required><br><br>

                <label for="tents">Number of Tent Requesting</label>
                <select id="tents" name="tents" required>
                    <option value="No Tent">No Tent</option>
                    <option value="One Tent">One Tent</option>
                    <option value="Two Tents">Two Tents</option>
                </select><br><br>

                <label for="chairs">Number of Chairs Requesting</label>
                <select id="chairs" name="chairs" required>
                    <option value="No Chairs">No Chairs</option>
                    <option value="Ten Chairs">Ten Chairs</option>
                    <option value="Fifteen Chairs">Fifteen Chairs</option>
                    <option value="Twenty Chairs">Twenty Chairs</option>
                </select><br><br>

                <label for="purpose">Purpose</label>
                <select id="purpose" name="purpose" required>
                    <option value="For Birthday">For Birthday</option>
                    <option value="For Christening Day">For Christening Day</option>
                    <option value="For Funeral">For Funeral</option>
                    <option value="For Other Events">For Other Events</option>
                </select><br><br>

                </div>
            </div>

                <input type="checkbox" id="term_agreement" name="term_agreement" required>
                <label for="term_agreement">I agree to the <a target="_blank">terms and conditions</a></label><br>
                <div id="term_agreement_error"></div><br>

                <input type="submit" value="Submit Application">

                <div id="termsModal" class="modal">
            <div class="modal-content">
                <span class="close" onclick="closeModal()">&times;</span>
            <h1>Terms and Conditions</h1>

            <p>Welcome to the Barangay Pembo's Services. Please read these terms and conditions carefully before using the service.</p><br>

            <h2>1. Acceptance of Terms</h2>
            <p>By using this service, you agree to be bound by these terms and conditions.</p><br>

            <h2>2. Permitted Use</h2>
            <p>This service is meant for the specific purpose of applying for a permit, following the guidelines outlined in the application form.</p><br>


            <h2>3. User Responsibilities</h2>
            <p>Users are responsible for providing accurate information in the permit application form. Any false information may result in the rejection of the application.</p><br>

            <h2>4. Privacy Assurance</h2>
            <p>We highly value your privacy and are dedicated to protecting your personal information. Kindly review our Privacy Policy below for a thorough understanding of how we manage, utilize, and safeguard your data.</p><br>


            <h2>5. Changes to Terms</h2>
            <p>We reserve the right to update or change these terms and conditions at any time. The updated terms will be effective upon posting to the website.</p><br>

            <p>For any questions regarding these terms and conditions, please contact us at <a href="https://www.facebook.com/MyBarangayPembo" class="contact-link">Facebook/MyBarangayPembo</a>.</p>
        </div>
    </div>
    </form>

    <script src="script.js"></script>
    <script>
        function validateContact() {
            const contactInput = document.getElementById('contact');
            const contactHelp = document.getElementById('contactHelp');
            const contactIndicator = document.getElementById('contactIndicator');
            const validContactFormat = /^\d+$/; // Regex to match only numbers

            contactIndicator.style.color = 'red';

            if (!validContactFormat.test(contactInput.value)) {
                contactIndicator.textContent = '*Contact Number Should Contain Only Numbers!';
                contactHelp.style.display = 'block';
                contactIndicator.style.display = 'inline';
            } else {
                contactIndicator.textContent = '';
                contactHelp.style.display = 'none';
                contactIndicator.style.display = 'none';
            }
        }

        function confirmSubmit() {
            return confirm("Are you sure you want to submit? Please Capture your Information before Submitting");
        }

        var modal = document.getElementById('termsModal');
        var termsLink = document.getElementById("term_agreement");

        termsLink.onclick = function () {
            modal.style.display = "block";
        }

        function closeModal() {
            modal.style.display = "none";
        }

        window.onclick = function (event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>
</body>

</html>

<?php
// Clear the form values session variable after displaying the form
unset($_SESSION['form_values']);
?>
