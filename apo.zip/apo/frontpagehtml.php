<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mental Wellness: A Development of an Inclusive and Supportive Website for Mental Health</title>
    <link rel="stylesheet" href="frontpage.css">
</head>
<body>
    <div class="container">
        <div class="content">
            <button onclick="redirectToLogin()">Login / Sign Up</button>
        </div>
    </div>
    <script>
        function redirectToLogin() {
            window.location.href = "loginhtml.php";
        }
    </script>
</body>
</html>