<?php
include_once 'lib/Database.php';

class HistoryPass {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    public function getPasswordHistory($userId) {
        try {
            $sql = "SELECT * FROM password_history WHERE user_id = :user_id ORDER BY change_date DESC";
            $stmt = $this->db->pdo->prepare($sql);
            $stmt->bindValue(':user_id', $userId);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            // Handle any database errors here
            echo "Error executing query: " . $e->getMessage();
            return false;
        }
    }
}

// Usage example
$historyPass = new HistoryPass();
$userId = 1; // Replace with the actual user ID
$passwordHistory = $historyPass->getPasswordHistory($userId);

// Display password history
if ($passwordHistory) {
    echo "<h2>Password History for User ID: $userId</h2>";
    echo "<table>";
    echo "<thead><tr><th>Password</th><th>Date</th></tr></thead>";
    echo "<tbody>";
    foreach ($passwordHistory as $history) {
        echo "<tr>";
        echo "<td>" . $history['new_password'] . "</td>"; // Display the new password
        echo "<td>" . $history['change_date'] . "</td>"; // Display the change date
        echo "</tr>";
    }
    echo "</tbody></table>";}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password History</title>
</head>
<style>
    table {
        width: 100%;
        border-collapse: collapse;
    }

    th, td {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
    }

    th {
        background-color: #f2f2f2;
    }

    tr:nth-child(even) {
        background-color: #f2f2f2;
    }
</style>
<body>
<h1>Password History</h1>
<table>
    <thead>
    <tr>
        <th>Password</th>
        <th>Date</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($passwordHistory as $history) : ?>
        <tr>
            <td><?php echo $history['new_password']; ?></td>
            <td><?php echo $history['change_date']; ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</body>

</html>
