<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms and Conditions</title>
    <!-- Replace 'your_styles.css' with the actual stylesheet you want to use -->
    <link rel="stylesheet" type="text/css" href="your_styles.css">
</head>
<body>

    <h1>Terms and Conditions</h1>

    <p>Welcome to the Barangay Basketball Court Permit Application. Please read these terms and conditions carefully before using the service.</p>

    <h2>1. Acceptance of Terms</h2>
    <p>By using this service, you agree to be bound by these terms and conditions.</p>

    <h2>2. Permitted Use</h2>
    <p>You may use this service for the purpose of applying for a basketball court permit as outlined in the application form.</p>

    <h2>3. User Responsibilities</h2>
    <p>Users are responsible for providing accurate information in the permit application form. Any false information may result in the rejection of the application.</p>

    <h2>4. Privacy Policy</h2>
    <p>We respect your privacy. Please refer to our <a href="privacy_policy.html">Privacy Policy</a> for details on how we collect, use, and disclose information.</p>

    <h2>5. Changes to Terms</h2>
    <p>We reserve the right to update or change these terms and conditions at any time. The updated terms will be effective upon posting to the website.</p>

    <p>For any questions regarding these terms and conditions, please contact us at <a href="mailto:info@example.com">info@example.com</a>.</p>

</body>
</html>
