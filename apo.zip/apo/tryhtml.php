<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Basketball Court Permit Application</title>
    <link rel="stylesheet" type="text/css" href="brgypermit.css">
    <link rel="stylesheet" href="reset.css">
    <style>
        body {
            position: relative;
        }

        #term_agreement {
            opacity: 0;
            position: absolute;
            margin-left: 20px; /* Adjust the margin based on your layout */
        }

        label[for="term_agreement"] {
            position: relative;
            cursor: pointer;
            display: inline-block; /* Ensures the label and checkbox are on the same line */
        }

        #term_agreement+label:before {
            content: "";
            position: absolute;
            left: -20px;
            top: 1px;
            width: 15px;
            height: 15px;
            background-color: #fff;
            border: 2px solid #000;
        }

        #term_agreement:checked+label:before {
            content: "✔";
            background-color: white;
            color: black;
            border-color: black;
            font-size: 14px;
            font-weight: bolder;
            text-align: center;
            line-height: 11px;
        }

        #term_agreement_error {
            display: none;
            color: red;
            font-weight: bold;
            margin-top: 5px;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            background-color: rgb(0, 0, 0);
            background-color: rgba(0, 0, 0, 0.4);
        }

        .modal-content {
            background-color: #fefefe;
            margin: 10% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 50%;
            text-align: left;
            border: solid black;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -75%);
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        h2 {
            font-weight: bold;
        }

        .contact-link {
            color: #007bff; /* Change the color as needed */
            text-decoration: underline; /* Add an underline to the link */
            cursor: pointer;
        }
    </style>

</head>
<body>
    <nav>
        <ul>
            <div class="logo">
                <img src="images/pemboLogo.png" alt="Barangay Pembo Logo">
            </div>
            <li><a href="mainhtml.php">HOME</a></li>
            <li><a href="CourtLocationhtml.php">BASKETBALL COURT LOCATION</a></li>
            <li><a href="Serviceshtml.php">BARANGAY SERVICES</a></li>
            <div class="logo2">
                <img src="images/makatiLogo.png" alt="Barangay Pembo Logo">
            </div>
        </ul>
    </nav>
    
    <form action="process_permit.php" method="post" onsubmit="return confirmSubmit()">
        <h1>Pembo Basketball Court Permit Application</h1><br>
        
        <?php
        session_start();
        if (isset($_SESSION['error_message'])) {
            echo '<div style="color: red; font-weight: bold;">' . $_SESSION['error_message'] . '</div>';
            unset($_SESSION['error_message']);
        }
        if (isset($_SESSION['success_message'])) {
            echo '<div style="color: green; font-weight: bold;">' . $_SESSION['success_message'] . '</div>';
            unset($_SESSION['success_message']);
        }
        ?><br>

        <div class="container">
            <div class="container1">
                <label for="name">Full Name</label>
                <input type="text" id="name" name="name" value="<?php echo isset($_SESSION['form_values']['name']) ? $_SESSION['form_values']['name'] : ''; ?>" required><br><br>

                <label for="address">Address</label>
                <input type="text" id="address" name="address" value="<?php echo isset($_SESSION['form_values']['address']) ? $_SESSION['form_values']['address'] : ''; ?>" required><br><br>

                <label for="contact">Contact Number</label>
                <input type="tel" id="contact" oninput="validateContact()" name="contact" value="<?php echo isset($_SESSION['form_values']['contact']) ? $_SESSION['form_values']['contact'] : ''; ?>" required>
                <span id="contactIndicator" class="contact-indicator"></span><br><br>

                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" value="<?php echo isset($_SESSION['form_values']['email']) ? $_SESSION['form_values']['email'] : ''; ?>" required><br><br>
            </div>

            <div class="container2">
                <label for="date">Date Requested</label>
                <input type="date" id="date" name="date" value="<?php echo isset($_SESSION['form_values']['date']) ? $_SESSION['form_values']['date'] : ''; ?>" required>
                <br><br>

                <label for="time">Time Requested</label>
                <select id="time" name="time" required>
                    <option value="6:00am - 8:00am">6:00am - 8:00am</option>
                    <option value="8:00am - 10:00am">8:00am - 10:00am</option>
                    <option value="10:00am - 12:00pm">10:00am - 12:00pm</option>
                    <option value="12:00pm - 2:00pm">12:00pm - 2:00pm</option>
                    <option value="2:00pm - 4:00pm">2:00pm - 4:00pm</option>
                    <option value="4:00pm - 6:00pm">4:00pm - 6:00pm</option>
                    <option value="6:00pm - 8:00pm">6:00pm - 8:00pm</option>
                </select><br><br>

                <label for="courtlocation">Permit For</label>
                <select id="courtlocation" name="courtlocation" required>
                    <option value="Cactus Pembo">To Use Basketball Court in Cactus Pembo</option>
                    <option value="Umbel Pembo">To Use Basketball Court in Umbel Pembo</option>
                    <option value="Brgy. Hall Pembo">To Use Basketball Court in Barangay Hall Pembo</option>
                </select><br><br>

                <label for="purpose">Purpose</label>
                <select id="purpose" name="purpose" required>
                    <option value="Liga">Basketball</option>
                    <option value="Birthday Event">Birthday Event</option>
                    <option value="Christening Day">Christening Day</option>
                    <option value="Group Practice">Group Practice</option>
                    <option value="Liga">Liga Event</option>
                    <option value="Social">Social Gathering</option>
                </select>
            </div>
        </div>

        <div><br>
        <input type="checkbox" id="term_agreement" name="term_agreement" required>
        <label for="term_agreement">I agree to the <a target="_blank">terms and conditions</a></label><br>
        <div id="term_agreement_error"></div><br>

        <input type="submit" value="Submit Application">

        <div id="termsModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
        <h1>Terms and Conditions</h1>

        <p>Welcome to the Barangay Pembo's Services. Please read these terms and conditions carefully before using the service.</p><br>

        <h2>1. Acceptance of Terms</h2>
        <p>By using this service, you agree to be bound by these terms and conditions.</p><br>

        <h2>2. Permitted Use</h2>
        <p>This service is meant for the specific purpose of applying for a permit, following the guidelines outlined in the application form.</p><br>


        <h2>3. User Responsibilities</h2>
        <p>Users are responsible for providing accurate information in the permit application form. Any false information may result in the rejection of the application.</p><br>

        <h2>4. Privacy Assurance</h2>
        <p>We highly value your privacy and are dedicated to protecting your personal information. Kindly review our Privacy Policy below for a thorough understanding of how we manage, utilize, and safeguard your data.</p><br>


        <h2>5. Changes to Terms</h2>
        <p>We reserve the right to update or change these terms and conditions at any time. The updated terms will be effective upon posting to the website.</p><br>

        <p>For any questions regarding these terms and conditions, please contact us at <a href="https://www.facebook.com/MyBarangayPembo" class="contact-link">Facebook/MyBarangayPembo</a>.</p>

        </div>
    </div>
    </form>

    <script src="script.js"></script>
    <script>
        function validateContact() {
            const contactInput = document.getElementById('contact');
            const contactHelp = document.getElementById('contactHelp');
            const contactIndicator = document.getElementById('contactIndicator');
            const validContactFormat = /^\d+$/; // Regex to match only numbers

            contactIndicator.style.color = 'red';

            if (!validContactFormat.test(contactInput.value)) {
                contactIndicator.textContent = '*Contact Number Should Contain Only Numbers!';
                contactHelp.style.display = 'block';
                contactIndicator.style.display = 'inline';
            } else {
                contactIndicator.textContent = '';
                contactHelp.style.display = 'none';
                contactIndicator.style.display = 'none';
            }
        }

        function confirmSubmit() {
            return confirm("Are you sure you want to submit? Please Capture your Information before Submitting");
        }

        var modal = document.getElementById('termsModal');
        var termsLink = document.getElementById("term_agreement");

        termsLink.onclick = function () {
            modal.style.display = "block";
        }

        function closeModal() {
            modal.style.display = "none";
        }

        window.onclick = function (event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>
</body>

</html>

<?php
// Clear the form values session variable after displaying the form
unset($_SESSION['form_values']);
?>