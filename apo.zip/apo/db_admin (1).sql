-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2024 at 02:19 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `indigency_applications`
--

CREATE TABLE `indigency_applications` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `BIRTHDAY` date NOT NULL,
  `CONTACT` varchar(10) NOT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `ADDRESS` varchar(255) NOT NULL,
  `OWNER_NAME` varchar(255) NOT NULL,
  `YEARS` varchar(255) NOT NULL,
  `PURPOSE` varchar(255) NOT NULL,
  `CURRENTDATE` date NOT NULL,
  `STATUS` varchar(255) NOT NULL DEFAULT 'Pending',
  `REASON` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `indigency_applications`
--

INSERT INTO `indigency_applications` (`ID`, `NAME`, `BIRTHDAY`, `CONTACT`, `EMAIL`, `ADDRESS`, `OWNER_NAME`, `YEARS`, `PURPOSE`, `CURRENTDATE`, `STATUS`, `REASON`) VALUES
(1, 'Joseph Derige', '2024-01-17', '0939481023', 'jessiecaderige101@gmail.com', '555 Hilinai Street, Wailuku', 'Salvacion Abaag', '5', 'For Medical Assitance', '2024-01-11', 'Cancelled', NULL),
(5, 'test', '2002-06-09', '0912345678', 'paganahinutak@gmail.com', 'pembo', 'asd', '6', 'asd', '2024-05-14', 'pending', 'just give me a reason');

-- --------------------------------------------------------

--
-- Table structure for table `password_history`
--

CREATE TABLE `password_history` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `old_password` varchar(255) NOT NULL,
  `new_password` varchar(255) NOT NULL,
  `change_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permit_bcourt`
--

CREATE TABLE `permit_bcourt` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `ADDRESS` varchar(255) NOT NULL,
  `CONTACT` varchar(11) NOT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `CURRENTDATE` date NOT NULL,
  `DATEREQUESTED` date NOT NULL,
  `TIMEREQUESTED` varchar(50) NOT NULL,
  `COURTLOCATION` varchar(255) NOT NULL,
  `PURPOSE` text NOT NULL,
  `PERMIT_CODE` varchar(10) NOT NULL,
  `STATUS` varchar(255) DEFAULT 'pending',
  `REASON` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `permit_bcourt`
--

INSERT INTO `permit_bcourt` (`ID`, `NAME`, `ADDRESS`, `CONTACT`, `EMAIL`, `CURRENTDATE`, `DATEREQUESTED`, `TIMEREQUESTED`, `COURTLOCATION`, `PURPOSE`, `PERMIT_CODE`, `STATUS`, `REASON`) VALUES
(1, 'Larry Christian Baribar', '141 - E, 15TH AVENUE', '09394810111', 'baribarlarry23@gmail.com', '2024-01-08', '2024-01-09', '6:00am - 8:00am', 'Cactus Pembo', 'Liga', 'A5JJ7WC5', 'Approved', NULL),
(2, 'John Raymond Bautista', 'Block 206 Lot 17 Acacia St. Pembo Makati City', '09663059454', 'johnraymondbautista11@gmail.com', '2024-01-08', '2024-01-12', '2:00pm - 4:00pm', 'Umbel Pembo', 'Social', 'WX878B2K', 'Declined', NULL),
(3, 'Joseph Derige', '555 Hilinai Street, Wailuku', '09394810239', 'jessiecaderige101@gmail.com', '2024-01-11', '2024-01-17', '6:00am - 8:00am', 'Cactus Pembo', 'Liga', 'O6E0U4RE', 'pending', NULL),
(4, 'test', 'pembo', '09123456789', 'paganahinutak@gmail.com', '2024-05-14', '2024-05-31', '6:00am - 8:00am', 'Cactus Pembo', 'Liga', 'XKD4CKMT', 'Approved', 'sample');

-- --------------------------------------------------------

--
-- Table structure for table `req_tentnchairs`
--

CREATE TABLE `req_tentnchairs` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `ADDRESS` varchar(255) NOT NULL,
  `CONTACT` varchar(11) NOT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `CURRENTDATE` date NOT NULL,
  `DATEREQUESTED` date NOT NULL,
  `REQUESTED_UNTIL` date NOT NULL,
  `TENTS_REQUESTED` text NOT NULL,
  `CHAIRS_REQUESTED` text NOT NULL,
  `PURPOSE` text NOT NULL,
  `PERMIT_CODE` varchar(10) NOT NULL,
  `STATUS` varchar(255) DEFAULT 'pending',
  `REASON` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `req_tentnchairs`
--

INSERT INTO `req_tentnchairs` (`ID`, `NAME`, `ADDRESS`, `CONTACT`, `EMAIL`, `CURRENTDATE`, `DATEREQUESTED`, `REQUESTED_UNTIL`, `TENTS_REQUESTED`, `CHAIRS_REQUESTED`, `PURPOSE`, `PERMIT_CODE`, `STATUS`, `REASON`) VALUES
(1, 'Larry Christian Baribar', '141 - E, 15TH AVENUE', '09394810111', 'baribarlarry23@gmail.com', '2024-01-08', '2024-01-09', '2024-01-10', 'One Tent', 'Ten Chairs', 'For Christening Day', '5S4U3CNV', 'pending', ''),
(2, 'John Raymond Bautista', 'Block 206 Lot 17 Acacia St. Pembo Makati City', '09663059454', 'johnraymondbautista11@gmail.com', '2024-01-08', '2024-01-09', '2024-01-11', 'One Tent', 'Twenty Chairs', 'For Christening Day', '2KJZ88LI', 'pending', ''),
(3, 'Joseph Derige', '555 Hilinai Street, Wailuku', '09394810239', 'jessiecaderige101@gmail.com', '2024-01-10', '2024-01-15', '2024-01-24', 'One Tent', 'Fifteen Chairs', 'For Birthday', 'OKXYQBN2', 'Declined', ''),
(4, 'test', 'pembo', '09123456789', 'paganahinutak@gmail.com', '2024-05-14', '2024-05-15', '2024-05-22', 'No Tent', 'No Chairs', 'For Birthday', '9HB8CBVY', 'Declined', 'not available');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_roles`
--

CREATE TABLE `tbl_roles` (
  `id` int(11) NOT NULL COMMENT 'role_id',
  `role` varchar(255) DEFAULT NULL COMMENT 'role_text'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_roles`
--

INSERT INTO `tbl_roles` (`id`, `role`) VALUES
(1, 'Admin'),
(2, 'Editor'),
(3, 'User');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `mobile` varchar(25) DEFAULT NULL,
  `roleid` tinyint(4) DEFAULT NULL,
  `isActive` tinyint(4) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `login_attempts` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `name`, `username`, `email`, `password`, `mobile`, `roleid`, `isActive`, `created_at`, `updated_at`, `login_attempts`) VALUES
(43, 'Angelu G. Abaag', 'Statix', 'garcia.abaag1@gmail.com', '194bd9bc5d7745d52e86bb1cfd0cf3cd223cc854', '09394810239', 4, 0, '2024-01-08 14:48:19', '2024-01-08 14:48:19', 0),
(51, 'Larry Christian Baribar', 'Baribar.pembo', 'baribarlarry23@gmail.com', '24cbb0ab08733ed4cafb113bf4f8097159575285', '09089896771', 3, 0, '2024-05-10 19:03:54', '2024-05-10 19:03:54', 0),
(52, 'test', 'test.pembo', 'paganahinutak@gmail.com', '9f167a3c238928cb4a95c794a126f10d04e9ae95', '09123456789', 3, 0, '2024-05-14 05:05:18', '2024-05-14 05:05:18', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `indigency_applications`
--
ALTER TABLE `indigency_applications`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `password_history`
--
ALTER TABLE `password_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `permit_bcourt`
--
ALTER TABLE `permit_bcourt`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `req_tentnchairs`
--
ALTER TABLE `req_tentnchairs`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_roles`
--
ALTER TABLE `tbl_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `indigency_applications`
--
ALTER TABLE `indigency_applications`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `password_history`
--
ALTER TABLE `password_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permit_bcourt`
--
ALTER TABLE `permit_bcourt`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `req_tentnchairs`
--
ALTER TABLE `req_tentnchairs`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_roles`
--
ALTER TABLE `tbl_roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'role_id', AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
