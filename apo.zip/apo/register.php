<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Barangay Pembo - Makati City</title>
    <link rel="stylesheet" type="text/css" href="main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <?php
    session_start();

    include 'inc/header1.php';
    Session::CheckLogin();

    $register = "";

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
        // Append ".pembo" to the username before registering
        $_POST['username'] = $_POST['username'] . '.pembo';
        $register = $users->userRegistration($_POST);
    }

    if (isset($register)) {
        // Check if the keys are set before accessing them
        $_SESSION['form_values']['name'] = isset($_POST['name']) ? $_POST['name'] : '';
        $_SESSION['form_values']['username'] = isset($_POST['username']) ? $_POST['username'] : '';
        $_SESSION['form_values']['email'] = isset($_POST['email']) ? $_POST['email'] : '';
        $_SESSION['form_values']['mobile'] = isset($_POST['mobile']) ? $_POST['mobile'] : '';
        echo $register;
    }
    ?>
    
</head>
<body>
    <div class="card ">
        <div class="card-header">
            <h3 class='text-center1'>Account Registration</h3>
        </div>
        <div class="card-body">

            <div style="width:600px; margin:0px auto">

                <form class="" action="" method="post">
                    <div class="form-group pt-3">
                        <label for="name">Full Name</label>
                        <input type="text" name="name" class="form-control" value="<?php echo isset($_SESSION['form_values']['name']) ? $_SESSION['form_values']['name'] : ''; ?>">
                    </div>

                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" name="username" class="form-control" value="<?php echo isset($_SESSION['form_values']['username']) ? $_SESSION['form_values']['username'] : ''; ?>">
                    </div>

                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" name="email" class="form-control" value="<?php echo isset($_SESSION['form_values']['email']) ? $_SESSION['form_values']['email'] : ''; ?>">
                        <input type="hidden" name="roleid" value="3">
                    </div>

                    <div class="form-group">
                        <label for="mobile">Mobile Number</label>
                        <div class="mobile-input-container">
                            <input type="text" name="mobile" class="form-control" id="mobile" oninput="validateMobile()">
                        <span id="mobileIndicator" class="mobile-indicator"></span>
                    </div>

                    <div class="form-group">
                        <label for="password">Password</label>
                        <div class="password-input-container">
                            <input type="password" name="password" class="form-control" id="password" oninput="validatePassword()">
                            <i class="fas fa-eye" id="togglePassword"></i>
                        </div>
                        <span id="passwordIndicator" class="password-indicator"></span>
                    </div>

                    <div class="form-group">
                        <label for="confirm_password">Confirm Password</label>
                        <div class="password-input-container">
                            <input type="password" name="confirm_password" class="form-control" id="confirmPassword" oninput="validateConfirmPassword()">
                            <i class="fas fa-eye" id="toggleConfirmPassword"></i>
                            <span id="confirmPasswordIndicator" class="confirmpassword-indicator"></span>
                        </div>
                    </div>

                    <div class="form-btn">
                        <button type="submit" name="register" class="btn btn-success">Register</button>
                    </div>

                </form>
            </div>
        </div>
    </div>

    <script>
        function validateMobile() {
            const mobileInput = document.getElementById('mobile');
            const mobileHelp = document.getElementById('mobileHelp');
            const mobileIndicator = document.getElementById('mobileIndicator');
            const validMobileFormat = /^\d+$/; // Regex to match only numbers

            mobileIndicator.style.color = 'red';

            if (!validMobileFormat.test(mobileInput.value)) {
                mobileIndicator.textContent = '*Mobile Number Should Contain Only Numbers!';
                mobileHelp.style.display = 'block';
                mobileIndicator.style.display = 'inline';
            } else {
                mobileIndicator.textContent = '';
                mobileHelp.style.display = 'none';
                mobileIndicator.style.display = 'none';
            }
        }

        function validatePassword() {
            const passwordInput = document.getElementById('password');
            const passwordHelp = document.getElementById('passwordHelp');
            const passwordIndicator = document.getElementById('passwordIndicator');

            // Check each requirement individually
            let hasNumber = /\d/.test(passwordInput.value);
            let hasLowercase = /[a-z]/.test(passwordInput.value);
            let hasUppercase = /[A-Z]/.test(passwordInput.value);
            let hasSpecialChar = /[-!@#$%^&*()_+}{":;'?/>.<,]/.test(passwordInput.value);
            let isLengthValid = passwordInput.value.length == 12;

            // Set color to red initially
            passwordIndicator.style.color = 'red';

            // Set indicator text based on each requirement
            if (!hasNumber || !hasLowercase || !hasUppercase || !hasSpecialChar || !isLengthValid) {
                passwordIndicator.innerHTML = '';
                if (!hasNumber) passwordIndicator.innerHTML += '*Password must contain at least 1 number<br>';
                if (!hasLowercase) passwordIndicator.innerHTML += '*Password must contain at least 1 lowercase letter<br>';
                if (!hasUppercase) passwordIndicator.innerHTML += '*Password must contain at least 1 uppercase letter<br>';
                if (!hasSpecialChar) passwordIndicator.innerHTML += '*Password must contain at least 1 special character<br>';
                if (!isLengthValid) passwordIndicator.innerHTML += '*Password must be 12 characters<br>';

                passwordHelp.style.display = 'block';
                passwordIndicator.style.display = 'inline';
            } else {
                passwordIndicator.textContent = '*Password meets the requirements';
                passwordIndicator.style.color = 'green';
                passwordHelp.style.display = 'none';
            }
        }

        function validateConfirmPassword() {
            const newPassword = document.getElementById('password').value;
            const confirmPasswordInput = document.getElementById('confirmPassword');
            const confirmPasswordIndicator = document.getElementById('confirmPasswordIndicator');

            if (newPassword !== confirmPasswordInput.value) {
                confirmPasswordIndicator.textContent = '*Passwords not matched';
                confirmPasswordIndicator.style.color = 'red';
            } else {
                confirmPasswordIndicator.textContent = '';
            }
        }

        document.addEventListener('click', function(event) {
            const passwordIndicator = document.getElementById('passwordIndicator');
            const mobileIndicator = document.getElementById('mobileIndicator');
            const confirmPasswordIndicator = document.getElementById('confirmPasswordIndicator');

            if (!event.target.closest('#mobileIndicator')) {
                mobileIndicator.textContent = '';
                mobileIndicator.style.display = 'red'; 
            }

            if (!event.target.closest('#passwordIndicator')) {
                passwordIndicator.textContent = '';
                passwordIndicator.style.color = 'red';
            }

            if (!event.target.closest('#confirmPasswordIndicator')) {
                confirmPasswordIndicator.textContent = '';
                confirmPasswordIndicator.style.color = 'red';
            }
        });

        document.addEventListener('DOMContentLoaded', function () {
            const passwordInput = document.getElementById('password');
            const togglePasswordButton = document.getElementById('togglePassword');
            const confirmPassInput = document.getElementById('confirmPassword');
            const toggleConfirmPasswordButton = document.getElementById('toggleConfirmPassword');
            let holdTimer;

            const togglePassword = function () {
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);

                togglePasswordButton.classList.toggle('fa-eye-slash');
            };

            togglePasswordButton.addEventListener('mousedown', function (event) {
                    event.preventDefault(); 
                    holdTimer = setTimeout(togglePassword, 500); 
            });

            togglePasswordButton.addEventListener('click', function (event) {
                    event.preventDefault(); 
                    togglePassword();
            });

            const toggleConfirmPassword = function () {
                const confirmType = confirmPassInput.getAttribute('type') === 'password' ? 'text' : 'password';
                confirmPassInput.setAttribute('type', confirmType);

                toggleConfirmPasswordButton.classList.toggle('fa-eye-slash');
            };

            toggleConfirmPasswordButton.addEventListener('mousedown', function (event) {
                    event.preventDefault(); 
                    holdTimer = setTimeout(toggleConfirmPassword, 500); 
            });

            toggleConfirmPasswordButton.addEventListener('click', function (event) {
                    event.preventDefault(); 
                    toggleConfirmPassword();
            });               
          });


    </script>


<?php
// Clear the form values session variable after displaying the form
unset($_SESSION['form_values']);
?>
