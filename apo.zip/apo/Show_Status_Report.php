<?php

session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_admin";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
    if (isset($_SESSION['email'])) {
      $email = $_SESSION['email'];
    $sql = "SELECT tbl_users.name, tbl_users.mobile, tbl_users.email, 
    permit_bcourt.ID AS bcourt_id, permit_bcourt.ADDRESS AS bcourt_addr, permit_bcourt.REASON as bcourt_reason, permit_bcourt.STATUS AS bcourt, 
    req_tentnchairs.ID AS tentnchairs_id, req_tentnchairs.ADDRESS AS tentnchairs_addr, req_tentnchairs.REASON AS tentnchairs_reason, req_tentnchairs.STATUS AS tentnchairs, 
    indigency_applications.ID AS indigency_id, indigency_applications.ADDRESS AS indigency_addr, indigency_applications.REASON AS indigency_reason, indigency_applications.STATUS AS indigency 
    FROM tbl_users 
    LEFT JOIN permit_bcourt ON tbl_users.email = permit_bcourt.EMAIL 
    LEFT JOIN req_tentnchairs ON tbl_users.email = req_tentnchairs.EMAIL 
    LEFT JOIN indigency_applications ON tbl_users.email = indigency_applications.EMAIL  
    WHERE tbl_users.email = '$email'
    LIMIT 1";
    } else {
      echo "Email not found in session.";
      
      exit();
    }  

$result = $conn->query($sql);

?>

<?php
// Define SITEURL constant
define('SITEURL', 'login.php');
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ADMIN DASHBOARD</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://use.fontawesome.com/releases/v5.0.4/css/all.css" rel="stylesheet">
   
    <link rel="stylesheet" href="assets/style.css">
    <style>
        @import url('https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap');

        * {
            font-family: 'Josefin Sans', sans-serif;
        }

        body {
            height: 100vh;
            overflow: hidden;
        }

        .table-container {
            width: 80%; /* Adjust the width as needed */
            margin: auto; /* Center the container horizontally */
            transform: translateY(105px);
        }

        table {
            transform: translateY(40px);
            margin-bottom: 15px;
            width: 15rem;
            border-collapse: collapse;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border: solid 2px #fff;
            color: black;
            background-color: white;
            font-size: 16px;
        }

        span {
            color: #fff;
            
        }
    
        th, td {
            border: solid 2px #000000;
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #d3d3d3;
            color: black;
            text-align: center; 
            border: 2px solid black;
        }

        tr:hover {
            background-color: #999da0;
        }

        h2 {
            font-family: 'Josefin Sans', sans-serif;
            text-align: center;
            transform: translateY(30px);
            color: black;
            font-size: 28px; 
            font-weight: bold;
        }

        .status.approved {
            color: #008000;
        }

        .status.declined {
            color: #ff0000;
        }

        .status.cancelled {
             color: #ff0000;
        }


        body {
            background-image: url('images/MakatiWP2.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }

        button {
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
        }

        .navbar-brand1 {
            font-weight: bold;
            font-size:25px; /* Adjust the size as needed */
        }

        .container3 {
            width: 100%;
            margin: auto;
            padding-bottom: 100px;
            padding-top: 10px;
            padding-right: 20px;
            padding-left: 20px;
            background-color: rgba(169, 169, 169, 0.7); /* Grey with 70% opacity */
            border: 2px solid black;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        </style>

    </head>
</body>

<body>

      <div class="table-container">
            <div class="container3">
    <div class="container2">
    <nav class="navbar navbar-expand-md navbar-dark bg-dark card-header ml-" style="width:100%">
        <span class="navbar-brand1"><i class="fas fa-home mr-2"></i>Barangay Pembo's  Services</span>


        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
          <ul class="navbar-nav ml-auto">

            <li class="nav-item">
                <a class="nav-link" href="<?php echo SITEURL; ?>" onclick="return"><i class="fas fa-sign-out-alt mr-2"></i>User Lists</a>              
            </li>

          </ul>
        </div>
      </nav>
  </div>
    <table id="example" class="table table-striped table-bordered" style="width:100%">
        <h2>Request Status</h2> 
        <tr>
                <th>Name</th>
                <th>Contact</th>
                <th>Email</th>
                <th>Address</th>
                <th>Permit Court Status</th>
                <th>Indigency Status</th>
                <th>Tent & Chairs Status</th>
            </tr>
        <?php
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['name'] . "</td>";
                echo "<td>" . $row['mobile'] . "</td>";
                echo "<td>" . $row['email'] . "</td>";
                echo "<td>" . ($row['bcourt_addr'] != NULL ? $row['bcourt_addr'] : ($row['indigency_addr'] != NULL ? $row['indigency_addr'] : ($row['tentnchairs_addr'] != NULL ? $row['tentnchairs_addr'] : "N/A"))) . "</td>";
                echo "<td class='status " . strtolower($row['bcourt']) . "'>" . $row['bcourt'];
            if ($row['bcourt'] != 'Declined' && $row['bcourt'] != 'Cancelled' && $row['bcourt'] != 'Approved' && $row['bcourt'] != NULL) {
                echo " <button onclick=\"cancelRequest('permit_bcourt', " . $row['bcourt_id'] . ")\">Cancel</button>";
            }
            if ($row['bcourt'] == 'Declined'){
                echo "<br>Reason: ".$row['bcourt_reason'];
            }
            echo "</td>";

            echo "<td class='status " . strtolower($row['indigency']) . "'>" . $row['indigency'];
            if ($row['indigency'] != 'Declined' && $row['indigency'] != 'Cancelled' && $row['indigency'] != 'Approved' && $row['indigency'] != NULL) {
                echo " <button onclick=\"cancelRequest('indigency_applications', " . $row['indigency_id'] . ")\">Cancel</button>";
            }
            if ($row['indigency'] == 'Declined'){
                echo "<br>Reason: ".$row['indigency_reason'];
            }
            echo "</td>";

            echo "<td class='status " . strtolower($row['tentnchairs']) . "'>" . $row['tentnchairs'];
            if ($row['tentnchairs'] != 'Declined' && $row['tentnchairs'] != 'Cancelled' && $row['tentnchairs'] != 'Approved' && $row['tentnchairs'] != NULL) {
                echo " <button onclick=\"cancelRequest('req_tentnchairs', " . $row['tentnchairs_id'] . ")\">Cancel</button>";
            }
            if ($row['tentnchairs'] == 'Declined'){
                echo "<br>Reason: ".$row['tentnchairs_reason'];
            }
            echo "</td>";

                echo "</tr>";
            }
            ?>

</table>

<script>
function cancelRequest(table, id) {
    var confirmation = confirm("Are you sure you want to cancel this request?");
    if (confirmation) {
        // If the user confirms, send an AJAX request to update the status in the database
        fetch(`cancel_request.php?table=${table}&ID=${id}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.text();
            })
            .then(data => {
                // Handle the response if needed
                console.log(data);
                alert(data);  // Add an alert to display the response
            })
            .catch(error => {
                console.error('Fetch error:', error);
                alert('Error updating record. Please check the console for details.');
            });
    }
}
</script>
