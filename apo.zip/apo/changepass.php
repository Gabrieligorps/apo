<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Barangay Pembo - Makati City</title>
    <link rel="stylesheet" type="text/css" href="main.css">

    <?php
    include 'inc/header.php';
    Session::CheckSession();
    ?>

    <?php
    if (isset($_GET['id'])) {
      $userid = (int)$_GET['id'];
    }

    $changePass = ""; // Initialize $changePass variable

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['changepass'])) {
      $changePass = $users->changePasswordBysingelUserId($userid, $_POST);
    }

    if (!empty($changePass)) { // Check if $changePass is not empty
      echo $changePass;
    }
    ?>

</head>
<body>

<div class="card ">
    <div class="card-header">
        <!-- Move the history password button here -->
        <span class="float-left"> <a href="historypass.php?id=<?php echo $userid; ?>" class="btn btn-info">View Password History</a> </span>
        <h3>Change your password <span class="float-right"> <a href="profile.php?id=<?php echo $userid; ?>" class="btn btn-primary">Back</a> </span></h3>
    </div>
    <div class="card-body">

        <div style="width:600px; margin:0px auto">

            <form class="" action="" method="POST">
                <div class="form-group">
                    <label for="old_password">Old Password</label>
                    <input type="password" name="old_password"  class="form-control">
                </div>
                <div class="form-group">
                    <label for="new_password">New Password</label>
                    <input type="password" name="new_password"  class="form-control" id="new_password" oninput="validatePassword()">
                    <span id="newpasswordIndicator" class="newpassword-indicator"></span>
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" name="confirm_password" class="form-control" id="confirmPassword" oninput="validateConfirmPassword()">
                    <span id="confirmPasswordIndicator" class="confirmpassword-indicator"></span>
                </div>

                <div class="form-group text-center">
                    <button type="submit" name="changepass" class="btn btn-success">Change password</button>
                </div>

            </form>
        </div>
    </div>
</div>
    <script>
        function validatePassword() {
            const newpasswordInput = document.getElementById('new_password');
            const newpasswordHelp = document.getElementById('newpasswordHelp');
            const newpasswordIndicator = document.getElementById('newpasswordIndicator');

            // Check each requirement individually
            let hasNumber = /\d/.test(newpasswordInput.value);
            let hasLowercase = /[a-z]/.test(newpasswordInput.value);
            let hasUppercase = /[A-Z]/.test(newpasswordInput.value);
            let hasSpecialChar = /[-!@#$%^&*()_+}{":;'?/>.<,]/.test(newpasswordInput.value);
            let isLengthValid = newpasswordInput.value.length == 12;

            // Set color to red initially
            newpasswordIndicator.style.color = 'red';

            // Set indicator text based on each requirement
            if (!hasNumber || !hasLowercase || !hasUppercase || !hasSpecialChar || !isLengthValid) {
                newpasswordIndicator.innerHTML = '';
                if (!hasNumber) newpasswordIndicator.innerHTML += '*Password must contain at least 1 number<br>';
                if (!hasLowercase) newpasswordIndicator.innerHTML += '*Password must contain at least 1 lowercase letter<br>';
                if (!hasUppercase) newpasswordIndicator.innerHTML += '*Password must contain at least 1 uppercase letter<br>';
                if (!hasSpecialChar) newpasswordIndicator.innerHTML += '*Password must contain at least 1 special character<br>';
                if (!isLengthValid) newpasswordIndicator.innerHTML += '*Password must be 12 characters<br>';

                newpasswordHelp.textContent = ''; // Clear any previous error message
                newpasswordHelp.style.display = 'block';
                newpasswordIndicator.style.display = 'inline';
            } else {
                newpasswordIndicator.textContent = '*New Password meets the requirements';
                newpasswordIndicator.style.color = 'green';
                newpasswordHelp.style.display = 'none';
            }
        }

        function validateConfirmPassword() {
            const newPassword = document.getElementById('new_password').value;
            const confirmPasswordInput = document.getElementById('confirmPassword');
            const confirmPasswordIndicator = document.getElementById('confirmPasswordIndicator');

            if (newPassword !== confirmPasswordInput.value) {
                confirmPasswordIndicator.textContent = '*Passwords not matched';
                confirmPasswordIndicator.style.color = 'red';
            } else {
                confirmPasswordIndicator.textContent = '';
            }
        }

        document.addEventListener('click', function(event) {
            const newpasswordIndicator = document.getElementById('newpasswordIndicator');
            const confirmPasswordIndicator = document.getElementById('confirmPasswordIndicator');

            if (!event.target.closest('#newpasswordIndicator')) {
                newpasswordIndicator.textContent = '';
                newpasswordIndicator.style.color = 'red';
            }

            if (!event.target.closest('#confirmPasswordIndicator')) {
                confirmPasswordIndicator.textContent = '';
                confirmPasswordIndicator.style.color = 'red';
            }
        });
    </script>

</body>
</html>
